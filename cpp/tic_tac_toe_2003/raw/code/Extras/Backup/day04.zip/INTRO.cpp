void banner(void)		//Displays huge TTT banner!
{
clrscr();
cout<<"\n\n********************************************************************************"
    <<"\n       _________	     _________		       _________ "
<<endl<<"      /___  ___/            /___  ___/                /___  ___/ "
<<endl<<"         / / __  ______        / / _______  ______       / / ______  ______"
<<endl<<"        / / / / / ____/       / / / ___  / / ____/      / / / __  / / ____/"
<<endl<<"       / / / / / /           / / / /__/ / / /	       / / / / / / / /__    "
<<endl<<"      / / / / / /___        / / / /  / / / /___       / / / /_/ / / /___    "
<<endl<<"     /_/ /_/ /_____/       /_/ /_/  /_/ /_____/      /_/ /_____/ /_____/    "
<<endl<<"\n\n********************************************************************************";

cout <<"\n\n\t\t\tTic Tac Toe 2003 v1.0 - APLHA BUILD"
     <<"\n\n\t\t(c) Dicelords Interactive - http://www.dicelords.com"
     <<"\n\n\n\n\t\t\t     Press any key to continue";
getch();
}

void eval(char c)
{
if (c=='1' || c=='3')
   {
	ttt game;
	for (int count=1; count<=10; count++)
	{
		game.show();
		game.test(count, c);
	}
   }
}


void menu(void)
{
clrscr();
cout    <<"\n** MAIN MENU **\nOnly 1 & 3 are operational right now."
	<<"\n\n 1: 1 Player - Quick Game   >> Play a single game against the computer."
	<<"\n\n 2: 1 Player - Tournament   >> Play a series of games against the computer."
	<<"\n\n 3: 2 Player - Quick Game   >> Play a single game against a human opponent."
	<<"\n\n 4: 2 Player - Tournament   >> Play a series of games against a human opponent."
	<<"\n\n 5: Rules"
	<<"\n\n 6: Hall of Fame"
	<<"\n\n 7: Credits"
	<<"\n\n 0: Exit"
	<<"\n\n\nPlease enter an option number from above: ";

char c;
c=getche();
if (c<'0' || c>'7')
menu();
eval(c);
}
