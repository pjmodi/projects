#include<iostream.h>
#include<conio.h>
#include<stdlib.h>

class ttt
{
//-----------------------
//Variable Declarations |
//-----------------------
private:
 int ip;
 char t[11];			//TiC Tac Toe Main Board
 char b[11]; 			//Buffer
 char *ptr;			//Pointer to Buffer
 char c[2];			//Input String
 char *conv;			//Pointer to Input String

public:
 ttt(void);
 void get(void);
 void show(void);
 void convert(void);
 void test(int, char);
 void block(void);
 void get_computer_move(void);
};


#include"AI.CPP"
#include"FUNCTION.CPP"
#include"INTRO.CPP"


//-------------------------
//Main program starts here |
//-------------------------
void main()
{
 char getc='0';
 banner();	 	//Shows the big TTT banner!
 do
 {
	menu();          //Forces the user to select something from the menu
	cout << "\n\nPress 'M' to go back to the menu or any other key to exit.";
	getc=getch();
 }
 while (getc=='M' || getc=='m');
}

//**********************************************************************
