void ttt::block(void)
{
if( (t[1]==t[2]) && (t[3]=='3') )
     ip=3;
else if( (t[1]==t[3]) && (t[2]=='2') )
     ip=2;
else if( (t[2]==t[3]) && (t[1]=='1') )
     ip=1;
else if( (t[4]==t[5]) && (t[6]=='6') )
     ip=6;
else if( (t[4]==t[6]) && (t[5]=='5') )
     ip=5;
else if( (t[5]==t[6]) && (t[4]=='4') )
     ip=4;
else if( (t[7]==t[8]) && (t[9]=='9') )
     ip=9;
else if( (t[7]==t[9]) && (t[8]=='8') )
     ip=8;
else if( (t[8]==t[9]) && (t[7]=='7') )
     ip=7;
else if( (t[1]==t[4]) && (t[7]=='7') )
     ip=7;
else if( (t[1]==t[7]) && (t[4]=='4') )
     ip=4;
else if( (t[4]==t[7]) && (t[1]=='1') )
     ip=1;
else if( (t[2]==t[5]) && (t[8]=='8') )
     ip=8;
else if( (t[2]==t[8]) && (t[5]=='5') )
     ip=5;
else if( (t[5]==t[8]) && (t[2]=='2') )
     ip=2;
else if( (t[3]==t[6]) && (t[9]=='9') )
     ip=9;
else if( (t[6]==t[9]) && (t[3]=='3') )
     ip=3;
else if( (t[3]==t[9]) && (t[6]=='6') )
     ip=6;
else if( (t[1]==t[5]) && (t[9]=='9') )
     ip=9;
else if( (t[1]==t[9]) && (t[5]=='5') )
     ip=5;
else if( (t[5]==t[9]) && (t[1]=='1') )
     ip=1;
else if( (t[3]==t[5]) && (t[7]=='7') )
     ip=7;
else if( (t[3]==t[7]) && (t[5]=='5') )
     ip=5;
else if( (t[5]==t[7]) && (t[3]=='3') )
     ip=3;
else
	{
	     do
	     {
		ip = random(10);
	     } while(ip==0);
	}
}

// Get the computer's move
void ttt::get_computer_move(void)
{
block();

     itoa(ip,c,10);

     for (int i=1; i<=10; i++)       //Dis-allows duplicate entries
     {
	if (c[0]==b[i])
		{
		get_computer_move();
		}
     }
}