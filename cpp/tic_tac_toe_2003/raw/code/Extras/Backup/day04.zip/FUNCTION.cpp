//----------------------
//Function Definitions  |
//----------------------
ttt::ttt(void)  		//Constructor
{
ip=0;
t[0]='0'; t[1]='1'; t[2]='2'; t[3]='3'; t[4]='4';
t[5]='5'; t[6]='6'; t[7]='7'; t[8]='8'; t[9]='9';

b[0]=' '; b[1]=' '; b[2]=' '; b[3]=' '; b[4]=' ';
b[5]=' '; b[6]=' '; b[7]=' '; b[8]=' '; b[9]=' ';

ptr=b;
c[0]=' ';
}


void ttt::convert(void)
{
conv=c;
ip=atoi(conv);			//Function part of stdlib.h
}

void ttt::get(void)
{
cout << "Please enter a number between 1 & 9 - ";
c[0]=getche();			//Allows only one character input
getch();               		//Waits for player to confirm continuation

if (c[0]<'1' || c[0]>'9')	//Makes sure i/p is a number between 1-9
	{
	cout << endl;
	get();
	}

for (int i=1; i<=10; i++)       //Dis-allows duplicate entries
	{
	if (c[0]==b[i])
		{
		cout << "\nThis number has already been used. ";
		get();
		}
	}
}


void ttt::test(int count, char c)		//Checks for a winner or continues the game
{
//X's winning conditions
if (
	(t[1] == 'X' && t[2] == 'X' && t[3] == 'X') ||
	(t[4] == 'X' && t[5] == 'X' && t[6] == 'X') ||
	(t[7] == 'X' && t[8] == 'X' && t[9] == 'X') ||
	(t[1] == 'X' && t[4] == 'X' && t[7] == 'X') ||
	(t[2] == 'X' && t[5] == 'X' && t[8] == 'X') ||
	(t[3] == 'X' && t[6] == 'X' && t[9] == 'X') ||
	(t[1] == 'X' && t[5] == 'X' && t[9] == 'X') ||
	(t[3] == 'X' && t[5] == 'X' && t[7] == 'X')
   )
	{cout << "\n\nPlayer 1 WINS!!";}

//O's winning conditions
else if (
	(t[1] == 'O' && t[2] == 'O' && t[3] == 'O') ||
	(t[4] == 'O' && t[5] == 'O' && t[6] == 'O') ||
	(t[7] == 'O' && t[8] == 'O' && t[9] == 'O') ||
	(t[1] == 'O' && t[4] == 'O' && t[7] == 'O') ||
	(t[2] == 'O' && t[5] == 'O' && t[8] == 'O') ||
	(t[3] == 'O' && t[6] == 'O' && t[9] == 'O') ||
	(t[1] == 'O' && t[5] == 'O' && t[9] == 'O') ||
	(t[3] == 'O' && t[5] == 'O' && t[7] == 'O')
    )
	{cout << "\n\nPlayer 2 WINS!!";}

//Draw conditions
else if (count == 10)
	{cout << "\n\nIt's a Draw! Please try again.";}

else if (count%2 != 0)
		{
		cout << "\n\nPlayer 1's turn. ";
		get();
		convert();
		t[ip]='X';
		}
	else
		{
		cout << "\n\nPlayer 2's turn. ";
			if (c=='1')
			{
			get_computer_move(); 	
			}
			else if (c=='3')
			{
			get();
			convert();
			}
		t[ip]='O';
		}
}

void ttt::show(void)			//Clears screen & throws output
{
	clrscr();
	cout << "\n\n"
	     << "\t\t\t\t|\t\t|" << endl
	     << "\t\t\t" << t[1] << "\t|\t" << t[2] << "\t|\t" << t[3] << endl
	     << "\t\t\t\t|\t\t|" << endl
	     << "\t\t    -- -- -- -- -- -- -- -- -- -- -- -- -- --\n"
	     << "\t\t\t\t|\t\t|" << endl
	     << "\t\t\t" << t[4] << "\t|\t" << t[5] << "\t|\t" << t[6] << endl
	     << "\t\t\t\t|\t\t|" << endl
	     << "\t\t    -- -- -- -- -- -- -- -- -- -- -- -- -- --\n"
	     << "\t\t\t\t|\t\t|" << endl
	     << "\t\t\t" << t[7] << "\t|\t" << t[8] << "\t|\t" << t[9] << endl
	     << "\t\t\t\t|\t\t|\n\n";
		*ptr=c[0];
		ptr++;
}



//**********************************************************************